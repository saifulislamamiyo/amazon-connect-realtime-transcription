
Manipulate audio with an simple and easy high level interface.

See the README file for details, usage info, and a list of gotchas.


